# GCP Control Plane

Visual infrastructure control plane. Drag-and-drop GCP resources onto a canvas,
describe intent in natural language, and a multi-agent AI system generates and
applies Terraform — with a mandatory human approval gate before anything runs.

---

## Architecture

```
React Flow UI (Canvas + Chat + Deployments panel)
        │
        │  REST / JSON
        ▼
FastAPI Backend (Cloud Run)
        │
        ├─► GCS Bucket
        │     sessions/{id}/canvas.json
        │     sessions/{id}/plans/{id}.tf
        │     sessions/{id}/deployments/{id}.json
        │
        ├─► ADK Multi-Agent Graph
        │     Planner (gemini-2.5-flash) → classifies intent
        │     TF Codegen (gemini-2.5-pro) → generates HCL
        │     Validator (gemini-2.5-flash) → static + LLM review
        │     Reviewer (gemini-2.5-pro) → user-facing explanation
        │
        └─► Cloud Build
              ↓ terraform init + validate + plan + apply
              ↓ SA key fetched from Secret Manager per target project
         Project A / Project B / Project C
```

---

## Agent Graph

```
User message + Canvas state
        │
        ▼
  [planner_node]  ← gemini-2.5-flash — classifies intent
        │
        ├── generate_terraform / modify_canvas ──►  [tf_codegen_node]
        │                                                    │
        │                                           [validator_node]
        │                                                    │
        │                                           [reviewer_tf_node] ──► response
        │
        └── general_chat / explain / estimate ──►   [chat_node] ──► response
```

---

## Prerequisites

- GCP project with billing enabled
- Vertex AI API enabled
- Cloud Build API enabled
- Cloud Storage API enabled
- Secret Manager API enabled
- `gcloud` CLI authenticated
- Node.js >= 20
- Python >= 3.12
- Terraform >= 1.8

---

## Quick Start

### 1. Bootstrap control plane infrastructure

```bash
cd terraform-templates
cp terraform.tfvars.example terraform.tfvars
# Edit terraform.tfvars with your project_id

terraform init
terraform apply
```

Note the outputs: `gcs_bucket_name` and `cloud_build_trigger_id`.

### 2. Upload cloudbuild.yaml to GCS

```bash
gsutil cp deploy/cloudbuild.yaml gs://YOUR_BUCKET/cloudbuild/cloudbuild.yaml
```

### 3. Register target project SA keys

For each target project (A, B, C), create a SA key and store in Secret Manager:

```bash
# In target project
gcloud iam service-accounts create control-plane-deployer \
  --project=TARGET_PROJECT_ID

gcloud projects add-iam-policy-binding TARGET_PROJECT_ID \
  --member="serviceAccount:control-plane-deployer@TARGET_PROJECT_ID.iam.gserviceaccount.com" \
  --role="roles/editor"

gcloud iam service-accounts keys create key.json \
  --iam-account=control-plane-deployer@TARGET_PROJECT_ID.iam.gserviceaccount.com

# In control plane project
gcloud secrets create sa-key-TARGET_PROJECT_ID \
  --data-file=key.json \
  --project=CONTROL_PLANE_PROJECT_ID

rm key.json
```

### 4. Backend

```bash
cd backend
cp env.template .env
# Edit .env with your values

pip install -r requirements.txt
uvicorn backend.api.main:app --reload --port 8080
```

### 5. Frontend

```bash
cd frontend
npm install
cp .env.example .env.local
# Set VITE_API_URL=http://localhost:8080

npm run dev
```

Open http://localhost:5173

---

## Usage

1. **Register target projects** via API or UI:
   ```bash
   curl -X POST http://localhost:8080/api/v1/projects \
     -H "Content-Type: application/json" \
     -d '{
       "project_id": "my-target-project",
       "display_name": "My Project",
       "secret_name": "sa-key-my-target-project",
       "region": "us-central1"
     }'
   ```

2. **Open the canvas** — drag GCP resources from the left palette

3. **Describe in chat** — "Create a GKE autopilot cluster connected to a private VPC with Cloud SQL PostgreSQL"

4. **Review the plan** — Terraform panel shows generated HCL with validation status

5. **Approve** — Click the green Approve button. Cloud Build triggers. Monitor in Deployments tab.

---

## API Reference

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/v1/chat` | Send message, run agent graph |
| GET | `/api/v1/sessions/{id}/canvas` | Load canvas state |
| PUT | `/api/v1/sessions/{id}/canvas` | Save canvas state |
| GET | `/api/v1/sessions/{id}/plans` | List plans |
| GET | `/api/v1/plans/{session_id}/{plan_id}` | Get plan + HCL |
| POST | `/api/v1/plans/{plan_id}/approve` | Approve → trigger Cloud Build |
| GET | `/api/v1/builds/{build_id}` | Poll build status |
| GET | `/api/v1/projects` | List registered projects |
| POST | `/api/v1/projects` | Register target project |
| GET | `/health` | Readiness probe |

---

## Security Notes

- SA keys are **never** returned by the backend API — fetched inside Cloud Build only
- User input is **never** interpolated into system prompts — it goes in the user turn only
- API key auth is enforced in `production` environment (set `API_KEY` env var)
- All LLM calls check `finish_reason` before accessing response text
- Terraform outputs are audited to GCS per build
- PII: this system handles GCP resource configuration only — no personal data

---

## Cost Profile

| Component | Est. cost |
|-----------|-----------|
| gemini-2.5-pro (codegen + reviewer) | ~$0.02–0.08 per generation |
| gemini-2.5-flash (planner + validator) | ~$0.001–0.003 per generation |
| Cloud Run backend | ~$0–5/month at low traffic |
| GCS | Negligible |
| Cloud Build | $0.003/build minute (E2_MEDIUM) |

Enable context caching on system prompts to reduce Pro costs at scale.
