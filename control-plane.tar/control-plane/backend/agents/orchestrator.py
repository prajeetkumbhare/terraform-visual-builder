"""ADK Orchestrator — explicit named-node graph."""
from __future__ import annotations
import time
from typing import Any, TypedDict
from backend.agents.planner import PlannerAgent
from backend.agents.reviewer import ReviewerAgent
from backend.agents.tf_codegen import TerraformCodegenAgent
from backend.agents.validator import ValidatorAgent
from backend.core.exceptions import AgentError, ControlPlaneError
from backend.core.logging import get_logger
from backend.core.models import AgentIntent, AgentRunMetrics, CanvasState, TerraformPlan

logger = get_logger(__name__)

class GraphState(TypedDict, total=False):
    session_id: str
    user_message: str
    canvas_state: CanvasState
    conversation_history: list[dict]
    intent: AgentIntent
    terraform_plan: TerraformPlan
    response_message: str
    metrics: list[AgentRunMetrics]
    error: str | None

class AgentGraph:
    def __init__(self, planner=None, codegen=None, validator=None, reviewer=None):
        self._planner = planner or PlannerAgent()
        self._codegen = codegen or TerraformCodegenAgent()
        self._validator = validator or ValidatorAgent()
        self._reviewer = reviewer or ReviewerAgent()

    async def run(self, session_id: str, user_message: str, canvas_state: CanvasState, conversation_history: list | None = None) -> tuple[str, TerraformPlan | None, list[AgentRunMetrics]]:
        state: GraphState = {"session_id": session_id, "user_message": user_message, "canvas_state": canvas_state, "conversation_history": conversation_history or [], "metrics": [], "error": None}
        start = time.monotonic()
        try:
            state = await self._planner_node(state)
            if state.get("error"): return self._err(state["error"]), None, state["metrics"]
            intent = state["intent"]
            if intent.action in ("generate_terraform", "modify_canvas"):
                state = await self._codegen_node(state)
                if state.get("error"): return self._err(state["error"]), None, state["metrics"]
                state = await self._validator_node(state)
                state = await self._reviewer_tf_node(state)
            else:
                state = await self._chat_node(state)
        except ControlPlaneError as e:
            return self._err(str(e)), None, state.get("metrics", [])
        except Exception:
            logger.exception("graph_unexpected_error", session_id=session_id)
            return self._err("Unexpected error. Please try again."), None, []

        elapsed = (time.monotonic() - start) * 1000
        logger.info("graph_complete", session_id=session_id, elapsed_ms=round(elapsed, 1))
        return state.get("response_message", ""), state.get("terraform_plan"), state.get("metrics", [])

    async def _planner_node(self, state: GraphState) -> GraphState:
        try:
            intent, metrics = await self._planner.plan(state["user_message"], state["canvas_state"], state.get("conversation_history"))
            state["intent"] = intent; state["metrics"].append(metrics)
        except AgentError as e: state["error"] = str(e)
        return state

    async def _codegen_node(self, state: GraphState) -> GraphState:
        try:
            plan, metrics = await self._codegen.generate(state["intent"], state["canvas_state"], state["session_id"])
            state["terraform_plan"] = plan; state["metrics"].append(metrics)
        except AgentError as e: state["error"] = str(e)
        return state

    async def _validator_node(self, state: GraphState) -> GraphState:
        plan = state.get("terraform_plan")
        if not plan: return state
        try:
            vplan, metrics = await self._validator.validate(plan)
            state["terraform_plan"] = vplan
            if metrics: state["metrics"].append(metrics)
        except AgentError as e: logger.warning("validator_error", error=str(e))
        return state

    async def _reviewer_tf_node(self, state: GraphState) -> GraphState:
        plan, intent = state.get("terraform_plan"), state.get("intent")
        if not plan or not intent: state["response_message"] = "Terraform generated."; return state
        try:
            r, metrics = await self._reviewer.review_terraform(plan, intent)
            state["response_message"] = r; state["metrics"].append(metrics)
        except AgentError as e: state["error"] = str(e)
        return state

    async def _chat_node(self, state: GraphState) -> GraphState:
        canvas = state["canvas_state"]
        ctx = "\n".join(f"- {n.data.resource_type.value}: {n.data.display_name}" for n in canvas.nodes) or "Empty canvas."
        try:
            r, metrics = await self._reviewer.chat(state["user_message"], ctx)
            state["response_message"] = r; state["metrics"].append(metrics)
        except AgentError as e: state["error"] = str(e)
        return state

    def _err(self, msg: str) -> str:
        return f"⚠️ **Agent Error**\n\n{msg}\n\nPlease check your configuration and try again."
