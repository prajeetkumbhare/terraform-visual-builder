"""Planner Agent — classifies user intent using gemini-2.5-flash."""
from __future__ import annotations
import json
from backend.core.exceptions import ParseError
from backend.core.gemini_client import GeminiClient
from backend.core.logging import get_logger
from backend.core.models import AgentIntent, AgentRunMetrics, CanvasState

logger = get_logger(__name__)

_SYSTEM_PROMPT = """You are the Planner for a GCP infrastructure control plane.
Analyse the user message and canvas state, output ONLY valid JSON:
{
  "action": "generate_terraform"|"modify_canvas"|"explain_resource"|"estimate_cost"|"validate_config"|"general_chat",
  "target_projects": ["project-id"],
  "resource_types": ["gke_cluster"],
  "nl_description": "...",
  "canvas_modifications": [],
  "confidence": 0.95
}
Rules: deploy/build/apply -> generate_terraform. "add a X" -> modify_canvas AND generate_terraform.
Never output anything except the JSON object."""

class PlannerAgent:
    def __init__(self, client: GeminiClient | None = None) -> None:
        from backend.core.config import get_settings
        s = get_settings()
        self._client = client or GeminiClient(model_name=s.gemini_flash_model, fallback_model_name=s.gemini_flash_model)

    async def plan(self, user_message: str, canvas_state: CanvasState, conversation_history: list | None = None) -> tuple[AgentIntent, AgentRunMetrics]:
        canvas_summary = self._summarise_canvas(canvas_state)
        user_content = f"Current canvas:\n{canvas_summary}\n\nUser message:\n{user_message}\n\nClassify and return JSON only."
        raw, metrics = await self._client.generate(agent_name="planner", system_instruction=_SYSTEM_PROMPT, user_message=user_content, temperature=0.1)
        intent = self._parse_intent(raw)
        logger.info("planner_intent_resolved", action=intent.action, confidence=intent.confidence)
        return intent, metrics

    def _summarise_canvas(self, canvas: CanvasState) -> str:
        if not canvas.nodes:
            return "Canvas is empty."
        lines = [f"Canvas has {len(canvas.nodes)} nodes:"]
        for n in canvas.nodes:
            lines.append(f"  - [{n.data.resource_type.value}] {n.data.display_name} (project: {n.data.target_project_id})")
        return "\n".join(lines)

    def _parse_intent(self, raw: str) -> AgentIntent:
        raw = raw.strip()
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        try:
            return AgentIntent(**json.loads(raw))
        except Exception as e:
            raise ParseError(agent_name="planner", raw=raw) from e
