"""Terraform Codegen Agent — generates HCL from intent + canvas using gemini-2.5-pro."""
from __future__ import annotations
import re
from backend.core.gemini_client import GeminiClient
from backend.core.logging import get_logger
from backend.core.models import AgentIntent, AgentRunMetrics, CanvasState, TerraformPlan

logger = get_logger(__name__)

_SYSTEM_PROMPT = """You are a senior GCP Terraform engineer. Output COMPLETE, PRODUCTION-READY HCL only.
Rules:
1. Output ONLY HCL — no markdown, no preamble.
2. Include terraform{required_providers{}} block with google ~> 5.0.
3. Include provider "google" { project=var.project_id; region=var.region }.
4. Use var.project_id and var.region — never hardcode.
5. Add # --- variables.tf --- and # --- outputs.tf --- sections.
6. GKE: use autopilot mode + deletion_protection=true.
7. Cloud SQL: deletion_protection=true + backup_configuration enabled.
8. VPC: always create VPC + subnet, never use default VPC.
9. Cloud Run: min_instance_count=0, max_instance_count=10.
10. Add depends_on for connected resources.
11. Labels: managed-by="control-plane", session-id=var.session_id.
12. End with: # RESOURCE_SUMMARY: resource1, resource2, ..."""

class TerraformCodegenAgent:
    def __init__(self, client: GeminiClient | None = None) -> None:
        self._client = client or GeminiClient()

    async def generate(self, intent: AgentIntent, canvas_state: CanvasState, session_id: str, conversation_history: list | None = None) -> tuple[TerraformPlan, AgentRunMetrics]:
        user_content = self._build_prompt(intent, canvas_state, session_id)
        raw_hcl, metrics = await self._client.generate(agent_name="tf_codegen", system_instruction=_SYSTEM_PROMPT, user_message=user_content, temperature=0.15, max_output_tokens=8192)
        plan = self._build_plan(raw_hcl, intent, session_id)
        logger.info("terraform_generated", session_id=session_id, resource_count=len(plan.resource_summary))
        return plan, metrics

    def _build_prompt(self, intent: AgentIntent, canvas: CanvasState, session_id: str) -> str:
        nodes_desc = []
        for node in canvas.nodes:
            nodes_desc.append(f"Resource: {node.data.resource_type.value}\n  Name: {node.data.display_name}\n  Project: {node.data.target_project_id}\n  NL: {node.data.natural_language_description or 'none'}")
        edges_desc = [f"  {e.source} -> {e.target} ({e.relationship})" for e in canvas.edges]
        target_project = intent.target_projects[0] if intent.target_projects else (canvas.nodes[0].data.target_project_id if canvas.nodes else "PROJECT_ID")
        return f"""Generate Terraform for GCP infrastructure.
Session: {session_id}
Target project: {target_project}
Resources:\n{chr(10).join(nodes_desc) or 'No nodes.'}
Dependencies:\n{chr(10).join(edges_desc) or 'None.'}
NL description: {intent.nl_description or 'None.'}
Generate complete HCL now."""

    def _build_plan(self, raw_hcl: str, intent: AgentIntent, session_id: str) -> TerraformPlan:
        resource_summary: list[str] = []
        m = re.search(r"# RESOURCE_SUMMARY:\s*(.+)", raw_hcl)
        if m:
            resource_summary = [r.strip() for r in m.group(1).split(",")]
            raw_hcl = raw_hcl[:m.start()].rstrip()
        target = intent.target_projects[0] if intent.target_projects else "unknown"
        return TerraformPlan(session_id=session_id, terraform_hcl=raw_hcl, target_project_id=target, resource_summary=resource_summary)
