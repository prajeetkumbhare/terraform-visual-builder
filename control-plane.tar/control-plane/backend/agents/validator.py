"""Validator Agent — static heuristics + LLM semantic review."""
from __future__ import annotations
import json, re
from backend.core.gemini_client import GeminiClient
from backend.core.logging import get_logger
from backend.core.models import AgentRunMetrics, TerraformPlan

logger = get_logger(__name__)

_SYSTEM_PROMPT = """You are a Terraform/GCP security reviewer.
Output ONLY a JSON array of error strings. Empty array = no errors.
Only report genuine errors: missing required fields, security risks, broken references, hardcoded credentials.
Max 10 errors. If HCL is correct: []"""

_REQUIRED_BLOCKS = [(r"terraform\s*\{", "Missing terraform {} block"), (r'provider\s+"google"', "Missing google provider block"), (r"var\.project_id", "project_id not parameterised — must use var.project_id")]
_FORBIDDEN = [(r'(?i)(password|secret|api_key)\s*=\s*"[^"]{4,}"', "Possible hardcoded secret in HCL")]
_GKE_CHECKS = [(r'resource\s+"google_container_cluster"', r"deletion_protection\s*=\s*true", "GKE cluster missing deletion_protection = true")]
_SQL_CHECKS = [(r'resource\s+"google_sql_database_instance"', r"deletion_protection\s*=\s*true", "Cloud SQL missing deletion_protection = true")]

def _static_validate(hcl: str) -> list[str]:
    errors = []
    for pattern, msg in _REQUIRED_BLOCKS:
        if not re.search(pattern, hcl): errors.append(msg)
    for pattern, msg in _FORBIDDEN:
        if re.search(pattern, hcl): errors.append(msg)
    for rp, cp, msg in _GKE_CHECKS:
        if re.search(rp, hcl) and not re.search(cp, hcl): errors.append(msg)
    for rp, cp, msg in _SQL_CHECKS:
        if re.search(rp, hcl) and not re.search(cp, hcl): errors.append(msg)
    return errors

class ValidatorAgent:
    def __init__(self, client: GeminiClient | None = None) -> None:
        from backend.core.config import get_settings
        s = get_settings()
        self._client = client or GeminiClient(model_name=s.gemini_flash_model, fallback_model_name=s.gemini_flash_model)

    async def validate(self, plan: TerraformPlan) -> tuple[TerraformPlan, AgentRunMetrics | None]:
        static_errors = _static_validate(plan.terraform_hcl)
        if static_errors:
            plan.validation_errors = static_errors
            plan.is_valid = False
            return plan, None
        raw, metrics = await self._client.generate(agent_name="validator", system_instruction=_SYSTEM_PROMPT, user_message=f"Review this Terraform HCL:\n\n{plan.terraform_hcl[:6000]}", temperature=0.1)
        errors = self._parse(raw, plan.plan_id)
        plan.validation_errors = errors
        plan.is_valid = len(errors) == 0
        logger.info("validation_complete", plan_id=plan.plan_id, is_valid=plan.is_valid, errors=len(errors))
        return plan, metrics

    def _parse(self, raw: str, plan_id: str) -> list[str]:
        raw = raw.strip()
        if raw.startswith("```"): raw = raw.split("```")[1]; raw = raw[4:] if raw.startswith("json") else raw
        try:
            r = json.loads(raw)
            return [str(e) for e in r] if isinstance(r, list) else []
        except Exception:
            logger.warning("validator_parse_error", plan_id=plan_id)
            return []
