"""FastAPI application — control plane backend."""
from __future__ import annotations
import logging
from contextlib import asynccontextmanager
from datetime import datetime
from uuid import UUID

from fastapi import FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from backend.agents.graph import run_graph
from backend.core.config import get_settings
from backend.core.errors import ControlPlaneError, GCSError, SessionNotFoundError
from backend.core.logging import setup_logging
from backend.core.models import (
    ApplyStatus, ApprovalRequest, ApprovalResponse, CanvasState,
    ChatRequest, ChatResponse, DeploymentRecord, DeploymentStatusResponse, HealthResponse,
)
from backend.services import cloud_build_service, gcs_service
from backend.services.session_store import get_store

logger = logging.getLogger(__name__)
settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    setup_logging()
    logger.info("control_plane_starting")
    if not gcs_service.check_gcs_reachable():
        logger.warning("gcs_not_reachable_on_startup")
    yield
    logger.info("control_plane_shutting_down")


app = FastAPI(
    title="GCP Control Plane API",
    version="1.0.0",
    docs_url="/docs" if settings.api_environment != "production" else None,
    redoc_url=None,
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.api_cors_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)


@app.exception_handler(ControlPlaneError)
async def control_plane_error_handler(request: Request, exc: ControlPlaneError):
    logger.error("unhandled_domain_error", extra={"error": str(exc)}, exc_info=True)
    return JSONResponse(status_code=500, content={"detail": str(exc)})


@app.exception_handler(SessionNotFoundError)
async def session_not_found_handler(request: Request, exc: SessionNotFoundError):
    return JSONResponse(status_code=404, content={"detail": str(exc)})


@app.get("/health", response_model=HealthResponse, tags=["ops"])
async def health() -> HealthResponse:
    gcs_ok = gcs_service.check_gcs_reachable()
    gemini_ok = False
    try:
        from backend.core.gemini_client import get_model
        get_model()
        gemini_ok = True
    except Exception:
        pass
    return HealthResponse(
        status="healthy" if (gcs_ok and gemini_ok) else "degraded",
        gemini_reachable=gemini_ok,
        gcs_reachable=gcs_ok,
    )


@app.post("/api/v1/chat", response_model=ChatResponse, tags=["agent"])
async def chat(request: ChatRequest) -> ChatResponse:
    store = get_store()
    chat_history = store.get_chat_history(request.session_id)

    logger.info("chat_request_received", extra={
        "session_id": str(request.session_id),
        "message_length": len(request.message),
        "node_count": len(request.canvas_state.nodes),
    })

    final_state = run_graph(
        session_id=request.session_id,
        user_message=request.message,
        canvas_state=request.canvas_state,
        chat_history=chat_history,
    )

    store.update_chat_history(request.session_id, final_state.chat_history)
    store.save_canvas(request.session_id, final_state.canvas)

    try:
        gcs_service.save_canvas_state(
            str(request.session_id), final_state.canvas.model_dump(mode="json")
        )
    except GCSError as exc:
        logger.warning("canvas_gcs_persist_failed", extra={"error": str(exc)})

    deployment_id = None
    if final_state.plan and final_state.validation and final_state.validation.passed:
        deployment = DeploymentRecord(
            session_id=request.session_id,
            plan_id=final_state.plan.plan_id,
            status=ApplyStatus.AWAITING_APPROVAL,
            target_project=final_state.plan.target_project,
        )
        store.save_deployment(deployment)
        deployment_id = deployment.deployment_id

    return ChatResponse(
        session_id=request.session_id,
        reply=getattr(final_state, "_reply", "Processing complete."),
        updated_canvas=final_state.canvas,
        plan=final_state.plan,
        validation=final_state.validation,
        requires_approval=getattr(final_state, "_requires_approval", False),
        deployment_id=deployment_id,
    )


@app.post(
    "/api/v1/deployments/{deployment_id}/approve",
    response_model=ApprovalResponse,
    tags=["deployments"],
)
async def approve_deployment(
    deployment_id: UUID, request: ApprovalRequest, session_id: UUID,
) -> ApprovalResponse:
    store = get_store()
    deployment = store.get_deployment(session_id, deployment_id)

    if deployment.status != ApplyStatus.AWAITING_APPROVAL:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Deployment is in status '{deployment.status}' — cannot approve.",
        )

    deployment = deployment.model_copy(update={
        "status": ApplyStatus.APPROVED,
        "approved_by": request.approved_by,
        "approved_at": datetime.utcnow(),
    })
    store.update_deployment(deployment)

    tf_gcs_prefix = (
        f"gs://{settings.gcs_bucket_name}/terraform/{session_id}/{deployment.plan_id}/"
    )
    try:
        deployment = cloud_build_service.trigger_apply(deployment, tf_gcs_prefix)
        store.update_deployment(deployment)
    except Exception as exc:
        deployment = deployment.model_copy(
            update={"status": ApplyStatus.FAILED, "error_message": str(exc)}
        )
        store.update_deployment(deployment)
        raise HTTPException(status_code=502, detail=f"Failed to trigger apply: {exc}")

    logger.info("deployment_approved", extra={
        "deployment_id": str(deployment_id),
        "approved_by": request.approved_by,
        "build_id": deployment.cloud_build_id,
    })

    return ApprovalResponse(
        deployment_id=deployment_id,
        status=deployment.status,
        cloud_build_id=deployment.cloud_build_id,
        log_url=deployment.log_url,
    )


@app.get(
    "/api/v1/deployments/{deployment_id}/status",
    response_model=DeploymentStatusResponse,
    tags=["deployments"],
)
async def get_deployment_status(deployment_id: UUID, session_id: UUID) -> DeploymentStatusResponse:
    store = get_store()
    deployment = store.get_deployment(session_id, deployment_id)

    if deployment.cloud_build_id and deployment.status in {ApplyStatus.PLANNING, ApplyStatus.APPLYING}:
        try:
            build_status = cloud_build_service.get_build_status(deployment.cloud_build_id)
            if build_status["status"] != deployment.status:
                deployment = deployment.model_copy(update={
                    "status": build_status["status"],
                    "log_url": build_status.get("log_url", deployment.log_url),
                    "completed_at": build_status.get("finish_time")
                    if build_status["status"] in {ApplyStatus.SUCCEEDED, ApplyStatus.FAILED}
                    else None,
                })
                store.update_deployment(deployment)
        except Exception as exc:
            logger.warning("build_status_poll_failed", extra={"error": str(exc)})

    return DeploymentStatusResponse(
        deployment_id=deployment_id,
        status=deployment.status,
        cloud_build_id=deployment.cloud_build_id,
        log_url=deployment.log_url,
        error_message=deployment.error_message,
        completed_at=deployment.completed_at,
    )


@app.get("/api/v1/sessions/{session_id}/canvas", response_model=CanvasState, tags=["sessions"])
async def get_canvas(session_id: UUID) -> CanvasState:
    store = get_store()
    canvas = store.get_canvas(session_id)
    if canvas:
        return canvas
    try:
        state_dict = gcs_service.load_canvas_state(str(session_id))
        if state_dict:
            canvas = CanvasState(**state_dict)
            store.save_canvas(session_id, canvas)
            return canvas
    except GCSError:
        pass
    return CanvasState(session_id=session_id)
