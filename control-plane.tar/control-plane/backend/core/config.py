"""
Core configuration — all settings sourced from environment variables.
No secrets ever hardcoded. Fail fast on startup if required vars are missing.
"""
from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # ── GCP ──────────────────────────────────────────────────────────────────
    gcp_project_id: str = Field(..., alias="GCP_PROJECT_ID")
    gcp_region: str = Field(default="us-central1", alias="GCP_REGION")
    vertex_ai_location: str = Field(default="us-central1", alias="VERTEX_AI_LOCATION")

    # ── Gemini ────────────────────────────────────────────────────────────────
    gemini_model_primary: str = Field(
        default="gemini-2.5-flash", alias="GEMINI_MODEL_PRIMARY"
    )
    gemini_model_planner: str = Field(
        default="gemini-2.5-pro", alias="GEMINI_MODEL_PLANNER"
    )
    gemini_max_output_tokens: int = Field(
        default=8192, alias="GEMINI_MAX_OUTPUT_TOKENS"
    )
    gemini_temperature: float = Field(default=0.2, alias="GEMINI_TEMPERATURE")

    # ── GCS ───────────────────────────────────────────────────────────────────
    gcs_bucket_name: str = Field(..., alias="GCS_BUCKET_NAME")
    gcs_canvas_prefix: str = Field(default="canvas-states/", alias="GCS_CANVAS_PREFIX")
    gcs_terraform_prefix: str = Field(default="terraform/", alias="GCS_TERRAFORM_PREFIX")

    # ── Cloud Build ───────────────────────────────────────────────────────────
    cloud_build_trigger_id: str = Field(..., alias="CLOUD_BUILD_TRIGGER_ID")
    cloud_build_service_account: str = Field(..., alias="CLOUD_BUILD_SERVICE_ACCOUNT")

    # ── API ───────────────────────────────────────────────────────────────────
    api_cors_origins: list[str] = Field(
        default=["http://localhost:3000"], alias="API_CORS_ORIGINS"
    )
    api_environment: Literal["development", "staging", "production"] = Field(
        default="development", alias="API_ENVIRONMENT"
    )
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")

    # ── Session / State ───────────────────────────────────────────────────────
    session_ttl_seconds: int = Field(default=3600, alias="SESSION_TTL_SECONDS")

    @field_validator("gemini_model_primary", "gemini_model_planner")
    @classmethod
    def validate_model_not_deprecated(cls, v: str) -> str:
        deprecated = {
            "gemini-pro",
            "gemini-1.5-pro",
            "gemini-3-pro-preview",  # shut down March 9 2026
        }
        if v in deprecated:
            raise ValueError(
                f"Model '{v}' is deprecated/shut down. "
                "Use gemini-2.5-flash or gemini-2.5-pro."
            )
        return v

    model_config = {"populate_by_name": True, "env_file": ".env"}


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
