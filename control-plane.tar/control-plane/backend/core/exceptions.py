"""Typed exception hierarchy."""
from __future__ import annotations
from typing import Any

class ControlPlaneError(Exception):
    def __init__(self, message: str, detail: Any = None) -> None:
        super().__init__(message)
        self.detail = detail

class AgentError(ControlPlaneError): pass
class SafetyBlockError(AgentError):
    def __init__(self, agent_name: str, ratings: list | None = None) -> None:
        super().__init__(f"Agent '{agent_name}' response blocked by safety filters", detail={"ratings": ratings or []})
        self.agent_name = agent_name
        self.ratings = ratings or []
class MaxTokensError(AgentError):
    def __init__(self, agent_name: str) -> None:
        super().__init__(f"Agent '{agent_name}' hit max token limit")
        self.agent_name = agent_name
class ParseError(AgentError):
    def __init__(self, agent_name: str, raw: str) -> None:
        super().__init__(f"Agent '{agent_name}' returned unparseable output", detail={"raw_snippet": raw[:500]})
class QuotaError(AgentError):
    def __init__(self, retry_after: float | None = None) -> None:
        super().__init__("Gemini API quota exceeded", detail={"retry_after": retry_after})
        self.retry_after = retry_after
class ModelUnavailableError(AgentError): pass
class GCSError(ControlPlaneError): pass
class CloudBuildError(ControlPlaneError):
    def __init__(self, message: str, build_id: str | None = None) -> None:
        super().__init__(message, detail={"build_id": build_id})
        self.build_id = build_id
class SecretManagerError(ControlPlaneError): pass
class TerraformValidationError(ControlPlaneError):
    def __init__(self, errors: list[str]) -> None:
        super().__init__("Terraform validation failed", detail={"errors": errors})
        self.errors = errors
class AuthError(ControlPlaneError): pass
class ProjectNotFoundError(ControlPlaneError): pass
