"""
Gemini client wrapper.

Responsibilities:
- Initialise Vertex AI once, inject model via factory
- Check finish_reason on EVERY candidate before touching .text
- Exponential backoff via tenacity (not hand-rolled sleep)
- Fallback: gemini-2.5-pro → gemini-2.5-flash on 429 / 503
- Log token usage on every call
- Never leak API keys — auth via ADC / Workload Identity
"""
from __future__ import annotations

import logging
from typing import Any

import vertexai
from google.api_core.exceptions import GoogleAPICallError, ResourceExhausted, ServiceUnavailable
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
    before_sleep_log,
)
from vertexai.generative_models import (
    GenerationConfig,
    GenerativeModel,
    HarmBlockThreshold,
    HarmCategory,
    Part,
)

from backend.core.config import get_settings
from backend.core.errors import (
    MaxTokensError,
    ModelUnavailableError,
    ParseError,
    QuotaError,
    SafetyBlockError,
)
from backend.core.logging import llm_span

logger = logging.getLogger(__name__)

# Finish reasons that mean the response text is unusable
_EMPTY_FINISH_REASONS = {"SAFETY", "RECITATION", "OTHER"}
_TRUNCATED_FINISH_REASON = "MAX_TOKENS"

# Safety settings — block only high-confidence harmful content
_SAFETY_SETTINGS = {
    HarmCategory.HARM_CATEGORY_HATE_SPEECH: HarmBlockThreshold.BLOCK_ONLY_HIGH,
    HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: HarmBlockThreshold.BLOCK_ONLY_HIGH,
    HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: HarmBlockThreshold.BLOCK_ONLY_HIGH,
    HarmCategory.HARM_CATEGORY_HARASSMENT: HarmBlockThreshold.BLOCK_ONLY_HIGH,
}


def _init_vertex() -> None:
    settings = get_settings()
    vertexai.init(
        project=settings.gcp_project_id,
        location=settings.vertex_ai_location,
    )


_vertex_initialised = False


def get_model(model_name: str | None = None) -> GenerativeModel:
    global _vertex_initialised
    if not _vertex_initialised:
        _init_vertex()
        _vertex_initialised = True

    settings = get_settings()
    name = model_name or settings.gemini_model_primary
    return GenerativeModel(
        model_name=name,
        safety_settings=_SAFETY_SETTINGS,
    )


def _generation_config(max_tokens: int | None = None) -> GenerationConfig:
    settings = get_settings()
    return GenerationConfig(
        temperature=settings.gemini_temperature,
        max_output_tokens=max_tokens or settings.gemini_max_output_tokens,
        response_mime_type="text/plain",
    )


@retry(
    retry=retry_if_exception_type((ResourceExhausted, ServiceUnavailable)),
    wait=wait_exponential(multiplier=1, min=2, max=60),
    stop=stop_after_attempt(4),
    before_sleep=before_sleep_log(logger, logging.WARNING),
    reraise=False,
)
def _call_with_retry(
    model: GenerativeModel,
    contents: list[Any],
    generation_config: GenerationConfig,
) -> Any:
    return model.generate_content(
        contents=contents,
        generation_config=generation_config,
    )


def generate(
    *,
    agent_name: str,
    system_instruction: str,
    user_parts: list[str | Part],
    model_name: str | None = None,
    max_tokens: int | None = None,
    span_name: str = "generate",
) -> str:
    """
    Core generation call used by all agents.

    Args:
        agent_name:          Name of the calling agent (for logging/spans).
        system_instruction:  System prompt — NEVER contains user-supplied text.
        user_parts:          User turn content (sanitized before passing here).
        model_name:          Override the default model.
        max_tokens:          Override max_output_tokens.
        span_name:           OTel span name.

    Returns:
        The model's text response.

    Raises:
        SafetyBlockError:   Gemini blocked the response.
        MaxTokensError:     Response was truncated.
        ModelUnavailableError: Both primary and fallback failed.
        QuotaError:         Quota exhausted after all retries.
    """
    settings = get_settings()
    primary_model_name = model_name or settings.gemini_model_primary
    fallback_model_name = settings.gemini_model_primary  # flash is always fallback

    for attempt_model in [primary_model_name, fallback_model_name]:
        if attempt_model == primary_model_name and attempt_model == fallback_model_name:
            # Same model — only try once
            models_to_try = [primary_model_name]
        else:
            models_to_try = [primary_model_name, fallback_model_name]
        break

    last_exc: Exception | None = None

    for current_model_name in models_to_try:
        with llm_span(
            name=span_name,
            model_name=current_model_name,
            agent_name=agent_name,
        ) as span:
            try:
                model = get_model(current_model_name)
                # System instruction is set at model level, NOT injected into user turn
                model_with_system = GenerativeModel(
                    model_name=current_model_name,
                    system_instruction=system_instruction,
                    safety_settings=_SAFETY_SETTINGS,
                )
                gen_config = _generation_config(max_tokens)

                response = _call_with_retry(
                    model_with_system,
                    user_parts,
                    gen_config,
                )

                # ── finish_reason guard ───────────────────────────────────────
                if not response.candidates:
                    raise SafetyBlockError(agent_name, "NO_CANDIDATES")

                candidate = response.candidates[0]
                finish_reason = str(candidate.finish_reason.name)

                span.set_attribute("llm.finish_reason", finish_reason)

                if finish_reason in _EMPTY_FINISH_REASONS:
                    raise SafetyBlockError(agent_name, finish_reason)

                if finish_reason == _TRUNCATED_FINISH_REASON:
                    raise MaxTokensError(agent_name)

                # ── token logging ─────────────────────────────────────────────
                if response.usage_metadata:
                    tokens = response.usage_metadata.total_token_count
                    span.set_attribute("llm.tokens_used", tokens)
                    logger.info(
                        "llm_token_usage",
                        extra={
                            "agent": agent_name,
                            "model": current_model_name,
                            "tokens_used": tokens,
                            "prompt_tokens": response.usage_metadata.prompt_token_count,
                            "completion_tokens": response.usage_metadata.candidates_token_count,
                        },
                    )

                return candidate.text

            except (SafetyBlockError, MaxTokensError):
                raise  # Don't retry on content issues

            except ResourceExhausted as exc:
                logger.warning(
                    "quota_exhausted",
                    extra={"model": current_model_name, "agent": agent_name},
                )
                last_exc = exc
                if current_model_name == fallback_model_name:
                    raise QuotaError(
                        f"Quota exhausted on {current_model_name} after retries."
                    ) from exc
                continue  # Try fallback

            except ServiceUnavailable as exc:
                logger.warning(
                    "model_unavailable",
                    extra={"model": current_model_name, "agent": agent_name},
                )
                last_exc = exc
                continue  # Try fallback

            except GoogleAPICallError as exc:
                logger.error(
                    "gemini_api_error",
                    extra={"model": current_model_name, "error": str(exc)},
                )
                raise ModelUnavailableError(str(exc)) from exc

    raise ModelUnavailableError(
        f"All models failed. Last error: {last_exc}"
    )
