"""
Structured JSON logging + OpenTelemetry span helpers.
Every LLM call must open a span via llm_span() context manager.
"""
from __future__ import annotations

import json
import logging
import sys
import time
from contextlib import contextmanager
from typing import Any, Generator

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.cloud_trace import CloudTraceSpanExporter

from backend.core.config import get_settings


# ── JSON log formatter ────────────────────────────────────────────────────────

class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "timestamp": self.formatTime(record),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }
        # Attach any extra fields passed via logger.info("msg", extra={...})
        for key, val in record.__dict__.items():
            if key not in {
                "args", "asctime", "created", "exc_info", "exc_text",
                "filename", "funcName", "id", "levelname", "levelno",
                "lineno", "module", "msecs", "message", "msg", "name",
                "pathname", "process", "processName", "relativeCreated",
                "stack_info", "thread", "threadName",
            }:
                payload[key] = val
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload)


def setup_logging() -> None:
    settings = get_settings()
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JsonFormatter())
    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(settings.log_level.upper())


# ── OpenTelemetry tracer ──────────────────────────────────────────────────────

_tracer: trace.Tracer | None = None


def init_tracer() -> None:
    global _tracer
    provider = TracerProvider()
    provider.add_span_processor(
        BatchSpanProcessor(CloudTraceSpanExporter())
    )
    trace.set_tracer_provider(provider)
    _tracer = trace.get_tracer("control-plane")


def get_tracer() -> trace.Tracer:
    global _tracer
    if _tracer is None:
        init_tracer()
    return _tracer


@contextmanager
def llm_span(
    name: str,
    model_name: str,
    agent_name: str,
    extra_attrs: dict[str, Any] | None = None,
) -> Generator[trace.Span, None, None]:
    """
    Context manager that wraps every LLM call in an OTel span.
    Records model_name, agent_name, finish_reason, tokens_used.
    Always closes the span — even on exception.

    Usage:
        with llm_span("generate_tf", model_name="gemini-2.5-pro", agent_name="TFGeneratorAgent") as span:
            response = model.generate_content(...)
            span.set_attribute("tokens_used", response.usage_metadata.total_token_count)
            span.set_attribute("finish_reason", str(response.candidates[0].finish_reason))
    """
    tracer = get_tracer()
    logger = logging.getLogger(agent_name)
    start = time.perf_counter()

    with tracer.start_as_current_span(name) as span:
        span.set_attribute("llm.model_name", model_name)
        span.set_attribute("llm.agent_name", agent_name)
        if extra_attrs:
            for k, v in extra_attrs.items():
                span.set_attribute(k, str(v))
        try:
            yield span
        except Exception as exc:
            span.record_exception(exc)
            span.set_attribute("error", True)
            raise
        finally:
            elapsed_ms = (time.perf_counter() - start) * 1000
            span.set_attribute("llm.latency_ms", round(elapsed_ms, 2))
            logger.info(
                "llm_call_complete",
                extra={
                    "agent": agent_name,
                    "model": model_name,
                    "latency_ms": round(elapsed_ms, 2),
                },
            )
