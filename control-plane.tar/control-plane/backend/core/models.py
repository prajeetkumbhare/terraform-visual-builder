"""
Shared data models across agents, API, and services.
All models are strict Pydantic v2 — no arbitrary dicts crossing boundaries.
"""
from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any
from uuid import UUID, uuid4

from pydantic import BaseModel, Field, model_validator


# ── Canvas types ──────────────────────────────────────────────────────────────

class NodeType(str, Enum):
    GKE = "gke"
    VPC = "vpc"
    CLOUD_RUN = "cloud_run"
    CLOUD_SQL = "cloud_sql"
    CLOUD_STORAGE = "cloud_storage"
    PUBSUB = "pubsub"
    FIRESTORE = "firestore"
    LOAD_BALANCER = "load_balancer"
    ARTIFACT_REGISTRY = "artifact_registry"
    CUSTOM = "custom"


class NodePosition(BaseModel):
    x: float
    y: float


class CanvasNode(BaseModel):
    id: str
    type: NodeType
    label: str
    position: NodePosition
    config: dict[str, Any] = Field(default_factory=dict)
    description: str = ""
    target_project: str = ""


class CanvasEdge(BaseModel):
    id: str
    source: str
    target: str
    label: str = ""
    relationship: str = "depends_on"


class CanvasState(BaseModel):
    session_id: UUID = Field(default_factory=uuid4)
    nodes: list[CanvasNode] = Field(default_factory=list)
    edges: list[CanvasEdge] = Field(default_factory=list)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    version: int = 1

    @model_validator(mode="after")
    def validate_edges_reference_nodes(self) -> "CanvasState":
        node_ids = {n.id for n in self.nodes}
        for edge in self.edges:
            if edge.source not in node_ids or edge.target not in node_ids:
                raise ValueError(
                    f"Edge {edge.id} references unknown node: "
                    f"source={edge.source}, target={edge.target}"
                )
        return self


# ── Chat / agent message types ────────────────────────────────────────────────

class MessageRole(str, Enum):
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"
    AGENT = "agent"


class ChatMessage(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    role: MessageRole
    content: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    agent_name: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


# ── Agent state (flows through the ADK graph) ─────────────────────────────────

class AgentIntent(BaseModel):
    """Parsed output from IntentAgent."""
    action: str                        # e.g. "add_gke_cluster", "connect_vpc"
    resource_types: list[str]          # GCP resource types mentioned
    target_projects: list[str]         # Which projects are affected
    constraints: dict[str, Any]        # e.g. {"region": "us-central1", "ha": true}
    raw_nl: str                        # Original user text, sanitized
    confidence: float = 1.0


class TerraformPlan(BaseModel):
    """Generated Terraform — not yet applied."""
    plan_id: UUID = Field(default_factory=uuid4)
    session_id: UUID
    files: dict[str, str]              # filename → HCL content
    target_project: str
    resource_summary: list[str]        # Human-readable list of what will be created
    estimated_cost_usd_month: float | None = None
    gcs_path: str = ""                 # Set after upload to GCS
    created_at: datetime = Field(default_factory=datetime.utcnow)


class ValidationResult(BaseModel):
    """Output from ValidatorAgent."""
    passed: bool
    errors: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    security_findings: list[str] = Field(default_factory=list)


class ApplyStatus(str, Enum):
    PENDING = "pending"
    PLANNING = "planning"
    AWAITING_APPROVAL = "awaiting_approval"
    APPROVED = "approved"
    APPLYING = "applying"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"


class DeploymentRecord(BaseModel):
    deployment_id: UUID = Field(default_factory=uuid4)
    session_id: UUID
    plan_id: UUID
    status: ApplyStatus = ApplyStatus.PENDING
    target_project: str
    cloud_build_id: str | None = None
    log_url: str | None = None
    approved_by: str | None = None
    approved_at: datetime | None = None
    completed_at: datetime | None = None
    error_message: str | None = None
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ── Full ADK graph state ──────────────────────────────────────────────────────

class GraphState(BaseModel):
    """
    State object that flows through every node in the ADK agent graph.
    Immutable between nodes — each node returns a new copy.
    """
    session_id: UUID = Field(default_factory=uuid4)
    canvas: CanvasState = Field(default_factory=CanvasState)
    chat_history: list[ChatMessage] = Field(default_factory=list)
    current_user_message: str = ""

    # Populated progressively as graph executes
    intent: AgentIntent | None = None
    plan: TerraformPlan | None = None
    validation: ValidationResult | None = None
    deployment: DeploymentRecord | None = None

    # Error propagation — if set, graph routes to error handler
    error: str | None = None
    error_agent: str | None = None

    # Routing signal for conditional edges
    next_node: str | None = None

    class Config:
        arbitrary_types_allowed = True


# ── API request/response shapes ───────────────────────────────────────────────

class ChatRequest(BaseModel):
    session_id: UUID
    message: str = Field(..., min_length=1, max_length=4000)
    canvas_state: CanvasState


class ChatResponse(BaseModel):
    session_id: UUID
    reply: str
    updated_canvas: CanvasState | None = None
    plan: TerraformPlan | None = None
    validation: ValidationResult | None = None
    requires_approval: bool = False
    deployment_id: UUID | None = None


class ApprovalRequest(BaseModel):
    deployment_id: UUID
    approved_by: str = Field(..., min_length=1, max_length=200)


class ApprovalResponse(BaseModel):
    deployment_id: UUID
    status: ApplyStatus
    cloud_build_id: str | None = None
    log_url: str | None = None


class DeploymentStatusResponse(BaseModel):
    deployment_id: UUID
    status: ApplyStatus
    cloud_build_id: str | None = None
    log_url: str | None = None
    error_message: str | None = None
    completed_at: datetime | None = None


class HealthResponse(BaseModel):
    status: str
    gemini_reachable: bool
    gcs_reachable: bool
    version: str = "1.0.0"
