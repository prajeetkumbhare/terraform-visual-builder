"""
Cloud Build Service — triggers Terraform plan/apply via Cloud Build API.
SA key per target project is fetched from Secret Manager, never stored in memory.
"""
from __future__ import annotations
import json, logging
from datetime import datetime
from typing import Any
from google.cloud import secretmanager, storage
from google.cloud.devtools import cloudbuild_v1
from google.cloud.exceptions import GoogleCloudError
from backend.core.config import get_settings
from backend.core.errors import SecretManagerError, TerraformApplyError
from backend.core.models import ApplyStatus, DeploymentRecord

logger = logging.getLogger(__name__)


def _fetch_sa_key(target_project: str) -> str:
    settings = get_settings()
    secret_name = (
        f"projects/{settings.gcp_project_id}/secrets/sa-key-{target_project}/versions/latest"
    )
    try:
        client = secretmanager.SecretManagerServiceClient()
        response = client.access_secret_version(name=secret_name)
        return response.payload.data.decode("utf-8")
    except Exception as exc:
        raise SecretManagerError(f"Could not fetch SA key for '{target_project}': {exc}") from exc


def _store_sa_key_in_gcs(sa_key: str, session_id: str, plan_id: str) -> str:
    settings = get_settings()
    path = f"sa-keys/{session_id}/{plan_id}/sa-key.json"
    client = storage.Client()
    blob = client.bucket(settings.gcs_bucket_name).blob(path)
    blob.upload_from_string(sa_key, content_type="application/json")
    return f"gs://{settings.gcs_bucket_name}/{path}"


def _delete_sa_key_from_gcs(session_id: str, plan_id: str) -> None:
    settings = get_settings()
    path = f"sa-keys/{session_id}/{plan_id}/sa-key.json"
    try:
        client = storage.Client()
        blob = client.bucket(settings.gcs_bucket_name).blob(path)
        if blob.exists():
            blob.delete()
    except Exception as exc:
        logger.warning("failed_to_delete_sa_key", extra={"path": path, "error": str(exc)})


def _trigger_build(
    settings,
    steps: list[dict],
    deployment: DeploymentRecord,
    tags: list[str],
    timeout_seconds: int,
    substitutions: dict[str, str],
) -> tuple[str, str]:
    cb_client = cloudbuild_v1.CloudBuildClient()
    build = cloudbuild_v1.Build(
        steps=[cloudbuild_v1.BuildStep(**s) for s in steps],
        timeout={"seconds": timeout_seconds},
        substitutions=substitutions,
        tags=tags,
        service_account=settings.cloud_build_service_account,
    )
    operation = cb_client.create_build(project_id=settings.gcp_project_id, build=build)
    result = operation.metadata.build
    return result.id, result.log_url


def trigger_plan(deployment: DeploymentRecord, tf_gcs_prefix: str) -> DeploymentRecord:
    settings = get_settings()
    sa_key = _fetch_sa_key(deployment.target_project)
    sa_key_uri = _store_sa_key_in_gcs(sa_key, str(deployment.session_id), str(deployment.plan_id))

    steps = [
        {
            "name": "gcr.io/google.com/cloudsdktool/cloud-sdk:slim",
            "entrypoint": "bash",
            "args": ["-c",
                f"gsutil cp {sa_key_uri} /workspace/sa-key.json && "
                f"gsutil -m cp -r {tf_gcs_prefix}*.tf /workspace/terraform/"],
        },
        {
            "name": "hashicorp/terraform:1.7",
            "dir": "/workspace/terraform",
            "entrypoint": "sh",
            "args": ["-c",
                "export GOOGLE_APPLICATION_CREDENTIALS=/workspace/sa-key.json && "
                f"terraform init -backend-config=bucket=$TF_STATE_BUCKET "
                f"-backend-config=prefix=state/{deployment.plan_id} && "
                "terraform plan -out=/workspace/tfplan.binary"],
        },
        {
            "name": "gcr.io/google.com/cloudsdktool/cloud-sdk:slim",
            "entrypoint": "bash",
            "args": ["-c",
                f"gsutil cp /workspace/tfplan.binary {tf_gcs_prefix}plan.binary && "
                "shred -u /workspace/sa-key.json"],
        },
    ]
    try:
        build_id, log_url = _trigger_build(
            settings, steps, deployment,
            tags=["control-plane", "terraform-plan", str(deployment.plan_id)],
            timeout_seconds=600,
            substitutions={"TF_STATE_BUCKET": settings.gcs_bucket_name,
                           "TARGET_PROJECT": deployment.target_project},
        )
        logger.info("cloud_build_plan_triggered",
                    extra={"build_id": build_id, "deployment_id": str(deployment.deployment_id)})
        return deployment.model_copy(
            update={"status": ApplyStatus.PLANNING, "cloud_build_id": build_id, "log_url": log_url}
        )
    except GoogleCloudError as exc:
        _delete_sa_key_from_gcs(str(deployment.session_id), str(deployment.plan_id))
        raise TerraformApplyError("", "") from exc


def trigger_apply(deployment: DeploymentRecord, tf_gcs_prefix: str) -> DeploymentRecord:
    if not deployment.approved_at or not deployment.approved_by:
        raise ValueError("Cannot trigger apply without approval record.")
    settings = get_settings()
    sa_key = _fetch_sa_key(deployment.target_project)
    sa_key_uri = _store_sa_key_in_gcs(sa_key, str(deployment.session_id), str(deployment.plan_id))

    steps = [
        {
            "name": "gcr.io/google.com/cloudsdktool/cloud-sdk:slim",
            "entrypoint": "bash",
            "args": ["-c",
                f"gsutil cp {sa_key_uri} /workspace/sa-key.json && "
                f"gsutil -m cp -r {tf_gcs_prefix}*.tf /workspace/terraform/"],
        },
        {
            "name": "hashicorp/terraform:1.7",
            "dir": "/workspace/terraform",
            "entrypoint": "sh",
            "args": ["-c",
                "export GOOGLE_APPLICATION_CREDENTIALS=/workspace/sa-key.json && "
                f"terraform init -backend-config=bucket=$TF_STATE_BUCKET "
                f"-backend-config=prefix=state/{deployment.plan_id} && "
                "terraform apply -auto-approve"],
        },
        {
            "name": "gcr.io/google.com/cloudsdktool/cloud-sdk:slim",
            "entrypoint": "bash",
            "args": ["-c", "shred -u /workspace/sa-key.json"],
        },
    ]
    try:
        build_id, log_url = _trigger_build(
            settings, steps, deployment,
            tags=["control-plane", "terraform-apply", str(deployment.plan_id)],
            timeout_seconds=1800,
            substitutions={"TF_STATE_BUCKET": settings.gcs_bucket_name,
                           "TARGET_PROJECT": deployment.target_project,
                           "APPROVED_BY": deployment.approved_by},
        )
        logger.info("cloud_build_apply_triggered",
                    extra={"build_id": build_id, "approved_by": deployment.approved_by})
        return deployment.model_copy(
            update={"status": ApplyStatus.APPLYING, "cloud_build_id": build_id, "log_url": log_url}
        )
    except GoogleCloudError as exc:
        _delete_sa_key_from_gcs(str(deployment.session_id), str(deployment.plan_id))
        raise TerraformApplyError("", "") from exc


def get_build_status(build_id: str) -> dict[str, Any]:
    settings = get_settings()
    cb_client = cloudbuild_v1.CloudBuildClient()
    build = cb_client.get_build(project_id=settings.gcp_project_id, id=build_id)
    status_map = {
        cloudbuild_v1.Build.Status.SUCCESS: ApplyStatus.SUCCEEDED,
        cloudbuild_v1.Build.Status.FAILURE: ApplyStatus.FAILED,
        cloudbuild_v1.Build.Status.INTERNAL_ERROR: ApplyStatus.FAILED,
        cloudbuild_v1.Build.Status.TIMEOUT: ApplyStatus.FAILED,
        cloudbuild_v1.Build.Status.CANCELLED: ApplyStatus.FAILED,
        cloudbuild_v1.Build.Status.WORKING: ApplyStatus.APPLYING,
        cloudbuild_v1.Build.Status.QUEUED: ApplyStatus.APPLYING,
    }
    return {
        "status": status_map.get(build.status, ApplyStatus.APPLYING),
        "log_url": build.log_url,
        "finish_time": build.finish_time,
    }
