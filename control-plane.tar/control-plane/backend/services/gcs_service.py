"""
GCS Service — canvas state persistence and Terraform file management.

All GCS paths are deterministic and auditable:
  canvas-states/{session_id}/state.json
  terraform/{session_id}/{plan_id}/{filename}.tf
"""
from __future__ import annotations

import json
import logging
from datetime import datetime
from typing import Any

from google.cloud import storage
from google.cloud.exceptions import GoogleCloudError

from backend.core.config import get_settings
from backend.core.errors import GCSError

logger = logging.getLogger(__name__)

_client: storage.Client | None = None


def _get_client() -> storage.Client:
    global _client
    if _client is None:
        _client = storage.Client()
    return _client


def _get_bucket() -> storage.Bucket:
    settings = get_settings()
    return _get_client().bucket(settings.gcs_bucket_name)


def save_canvas_state(session_id: str, state_dict: dict[str, Any]) -> None:
    settings = get_settings()
    path = f"{settings.gcs_canvas_prefix}{session_id}/state.json"
    try:
        blob = _get_bucket().blob(path)
        blob.upload_from_string(
            json.dumps(state_dict, default=str),
            content_type="application/json",
        )
        logger.info("canvas_state_saved", extra={"session_id": session_id, "gcs_path": path})
    except GoogleCloudError as exc:
        raise GCSError(f"Failed to save canvas state: {exc}") from exc


def load_canvas_state(session_id: str) -> dict[str, Any] | None:
    settings = get_settings()
    path = f"{settings.gcs_canvas_prefix}{session_id}/state.json"
    try:
        blob = _get_bucket().blob(path)
        if not blob.exists():
            return None
        return json.loads(blob.download_as_text())
    except GoogleCloudError as exc:
        raise GCSError(f"Failed to load canvas state: {exc}") from exc


def upload_terraform_plan(session_id: str, plan_id: str, files: dict[str, str]) -> str:
    settings = get_settings()
    prefix = f"{settings.gcs_terraform_prefix}{session_id}/{plan_id}/"
    try:
        bucket = _get_bucket()
        for filename, content in files.items():
            blob = bucket.blob(f"{prefix}{filename}")
            blob.upload_from_string(content, content_type="text/plain")

        manifest = {
            "session_id": session_id,
            "plan_id": plan_id,
            "files": list(files.keys()),
            "uploaded_at": datetime.utcnow().isoformat(),
        }
        bucket.blob(f"{prefix}manifest.json").upload_from_string(
            json.dumps(manifest), content_type="application/json"
        )
        logger.info(
            "terraform_plan_uploaded",
            extra={"session_id": session_id, "plan_id": plan_id, "file_count": len(files)},
        )
        return f"gs://{settings.gcs_bucket_name}/{prefix}"
    except GoogleCloudError as exc:
        raise GCSError(f"Failed to upload Terraform plan: {exc}") from exc


def get_terraform_file(session_id: str, plan_id: str, filename: str) -> str:
    settings = get_settings()
    path = f"{settings.gcs_terraform_prefix}{session_id}/{plan_id}/{filename}"
    try:
        return _get_bucket().blob(path).download_as_text()
    except GoogleCloudError as exc:
        raise GCSError(f"Failed to download {path}: {exc}") from exc


def list_plan_files(session_id: str, plan_id: str) -> list[str]:
    settings = get_settings()
    prefix = f"{settings.gcs_terraform_prefix}{session_id}/{plan_id}/"
    try:
        blobs = _get_client().list_blobs(settings.gcs_bucket_name, prefix=prefix)
        return [b.name for b in blobs if not b.name.endswith("manifest.json")]
    except GoogleCloudError as exc:
        raise GCSError(f"Failed to list plan files: {exc}") from exc


def check_gcs_reachable() -> bool:
    try:
        _get_bucket().exists()
        return True
    except Exception:
        return False
