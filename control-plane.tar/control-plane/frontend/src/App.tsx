import React, { useCallback, useEffect, useState } from "react";
import { listProjects } from "./lib/api";
import { useStore } from "./store";
import { Canvas } from "./components/canvas/Canvas";
import { ChatPanel } from "./components/chat/ChatPanel";
import { TerraformPanel } from "./components/sidebar/TerraformPanel";
import { DeploymentsPanel } from "./components/sidebar/DeploymentsPanel";
import type { CanvasState, PanelTab } from "./types";

const TABS: Array<{ id: PanelTab; label: string; icon: string }> = [
  { id: "chat", label: "Chat", icon: "⎈" },
  { id: "terraform", label: "Terraform", icon: "⬡" },
  { id: "deployments", label: "Builds", icon: "▶" },
];

export default function App() {
  const { sessionId, activeTab, setActiveTab, setProjects, projects, pendingPlan } = useStore();
  const [canvasState, setCanvasState] = useState<CanvasState>({ session_id: sessionId, nodes: [], edges: [], updated_at: new Date().toISOString(), version: 1 });
  const defaultProjectId = projects[0]?.project_id ?? "my-gcp-project";

  useEffect(() => { listProjects().then(setProjects).catch(() => {}); }, [setProjects]);
  const onCanvasChange = useCallback((s: CanvasState) => setCanvasState({ ...s, session_id: sessionId }), [sessionId]);

  return (
    <div style={{ display:"flex",flexDirection:"column",height:"100vh",width:"100vw",background:"#0D1117",overflow:"hidden",fontFamily:"'JetBrains Mono','Fira Code',monospace" }}>
      {/* Header */}
      <header style={{ height:52,background:"#010409",borderBottom:"1px solid rgba(255,255,255,0.07)",display:"flex",alignItems:"center",padding:"0 24px",gap:20,flexShrink:0,zIndex:100 }}>
        <div style={{ display:"flex",alignItems:"center",gap:10 }}>
          <div style={{ width:28,height:28,borderRadius:6,background:"linear-gradient(135deg,#4285F4,#34A853)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14 }}>⎈</div>
          <span style={{ fontSize:13,fontWeight:800,color:"#F9FAFB",letterSpacing:"0.05em" }}>Control Plane</span>
        </div>
        <div style={{ width:1,height:20,background:"rgba(255,255,255,0.08)" }} />
        <span style={{ fontSize:9,color:"#374151",letterSpacing:"0.05em" }}>SESSION {sessionId.slice(0,8).toUpperCase()}</span>
        <div style={{ display:"flex",gap:6,marginLeft:"auto" }}>
          {projects.map(p => (
            <div key={p.project_id} style={{ fontSize:9,color:"#34A853",background:"#0a1f11",border:"1px solid #34A85333",borderRadius:4,padding:"3px 8px" }}>{p.project_id}</div>
          ))}
        </div>
        {pendingPlan && (
          <div style={{ display:"flex",alignItems:"center",gap:6,fontSize:10,color:"#FBBC04",background:"#1a1500",border:"1px solid #FBBC0433",borderRadius:6,padding:"4px 10px" }}>
            <span style={{ animation:"blink 1s step-end infinite" }}>●</span>
            Plan ready for approval
          </div>
        )}
        <style>{`@keyframes blink{0%,100%{opacity:1}50%{opacity:0}}`}</style>
      </header>

      {/* Main */}
      <div style={{ flex:1,display:"flex",overflow:"hidden" }}>
        <div style={{ flex:1,overflow:"hidden" }}>
          <Canvas defaultProjectId={defaultProjectId} onChange={onCanvasChange} sessionId={sessionId} />
        </div>
        {/* Right panel */}
        <div style={{ width:420,display:"flex",flexDirection:"column",borderLeft:"1px solid rgba(255,255,255,0.07)",flexShrink:0,background:"#0D1117" }}>
          {/* Tabs */}
          <div style={{ display:"flex",borderBottom:"1px solid rgba(255,255,255,0.07)",background:"#010409",flexShrink:0 }}>
            {TABS.map(tab => {
              const isActive = activeTab === tab.id;
              const hasDot = tab.id === "terraform" && !!pendingPlan;
              return (
                <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                  style={{ flex:1,padding:"12px 0",background:"transparent",border:"none",borderBottom:isActive?"2px solid #4285F4":"2px solid transparent",color:isActive?"#F9FAFB":"#4B5563",cursor:"pointer",fontSize:10,fontFamily:"'JetBrains Mono',monospace",fontWeight:isActive?700:400,letterSpacing:"0.08em",display:"flex",alignItems:"center",justifyContent:"center",gap:6,position:"relative" }}>
                  <span>{tab.icon}</span><span>{tab.label.toUpperCase()}</span>
                  {hasDot && <span style={{ width:6,height:6,borderRadius:"50%",background:"#FBBC04",position:"absolute",top:10,right:14 }} />}
                </button>
              );
            })}
          </div>
          <div style={{ flex:1,overflow:"hidden" }}>
            {activeTab==="chat"        && <ChatPanel canvasState={canvasState} />}
            {activeTab==="terraform"   && <TerraformPanel />}
            {activeTab==="deployments" && <DeploymentsPanel />}
          </div>
        </div>
      </div>
    </div>
  );
}
