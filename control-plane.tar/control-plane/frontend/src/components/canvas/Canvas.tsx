import React, { useCallback, useRef, useState } from "react";
import ReactFlow, { Background, BackgroundVariant, Controls, MiniMap, addEdge, useEdgesState, useNodesState, type Connection, type Edge, type Node, type OnConnect } from "reactflow";
import "reactflow/dist/style.css";
import { v4 as uuidv4 } from "uuid";
import { GCPResourceNode } from "./GCPResourceNode";
import type { CanvasState, NodeConfig, ResourceType } from "../../types";

const nodeTypes = { gcpResource: GCPResourceNode };

const PALETTE: Array<{ type: ResourceType; label: string; icon: string; color: string }> = [
  { type: "gke_cluster", label: "GKE Cluster", icon: "⎈", color: "#4285F4" },
  { type: "vpc_network", label: "VPC Network", icon: "⬡", color: "#34A853" },
  { type: "cloud_run_service", label: "Cloud Run", icon: "▶", color: "#FBBC04" },
  { type: "cloud_sql_instance", label: "Cloud SQL", icon: "⛃", color: "#EA4335" },
  { type: "gcs_bucket", label: "GCS Bucket", icon: "◈", color: "#9C27B0" },
  { type: "pubsub_topic", label: "Pub/Sub", icon: "⇆", color: "#00BCD4" },
  { type: "firestore", label: "Firestore", icon: "🔥", color: "#FF6D00" },
  { type: "load_balancer", label: "Load Balancer", icon: "⚖", color: "#607D8B" },
  { type: "artifact_registry", label: "Artifact Registry", icon: "📦", color: "#795548" },
  { type: "custom", label: "Custom Resource", icon: "✦", color: "#78909C" },
];

interface CanvasProps { defaultProjectId: string; onChange: (state: CanvasState) => void; sessionId: string; }

export function Canvas({ defaultProjectId, onChange, sessionId }: CanvasProps) {
  const wrapperRef = useRef<HTMLDivElement>(null);
  const [rfInstance, setRfInstance] = useState<any>(null);
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);

  const emit = useCallback((n: Node[], e: Edge[]) => {
    onChange({ session_id: sessionId, nodes: n.map(nd => ({ id: nd.id, type: nd.type ?? "gcpResource", position: nd.position, data: nd.data as NodeConfig })), edges: e.map(ed => ({ id: ed.id, source: ed.source, target: ed.target, label: (ed.label as string) ?? "", relationship: (ed.data?.relationship as any) ?? "depends_on" })), updated_at: new Date().toISOString(), version: 1 });
  }, [onChange, sessionId]);

  const onConnect: OnConnect = useCallback((params: Connection) => {
    setEdges(eds => { const next = addEdge({ ...params, id: uuidv4(), animated: true, style: { stroke: "#4B5563", strokeWidth: 2 }, data: { relationship: "depends_on" } }, eds); emit(nodes, next); return next; });
  }, [nodes, emit, setEdges]);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const type = e.dataTransfer.getData("application/reactflow-type") as ResourceType;
    if (!type || !rfInstance || !wrapperRef.current) return;
    const bounds = wrapperRef.current.getBoundingClientRect();
    const position = rfInstance.screenToFlowPosition({ x: e.clientX - bounds.left, y: e.clientY - bounds.top });
    const newNode: Node = { id: uuidv4(), type: "gcpResource", position, data: { resource_type: type, display_name: `${type.replace(/_/g,"-")}-${Math.floor(Math.random()*100)}`, natural_language_description: "", properties: {}, target_project_id: defaultProjectId } satisfies NodeConfig };
    setNodes(nds => { const next = [...nds, newNode]; emit(next, edges); return next; });
  }, [rfInstance, defaultProjectId, edges, emit, setNodes]);

  return (
    <div style={{ display: "flex", width: "100%", height: "100%" }}>
      {/* Palette */}
      <div style={{ width: 196, background: "#0D1117", borderRight: "1px solid rgba(255,255,255,0.07)", padding: "16px 8px", display: "flex", flexDirection: "column", gap: 4, overflowY: "auto", flexShrink: 0 }}>
        <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: "0.15em", color: "#374151", textTransform: "uppercase", paddingLeft: 8, marginBottom: 8, fontFamily: "'JetBrains Mono',monospace" }}>GCP Resources</div>
        {PALETTE.map(item => (
          <div key={item.type} draggable onDragStart={e => { e.dataTransfer.setData("application/reactflow-type", item.type); e.dataTransfer.effectAllowed = "move"; }}
            style={{ display: "flex", alignItems: "center", gap: 10, padding: "7px 10px", borderRadius: 6, border: "1px solid rgba(255,255,255,0.06)", background: "#161B22", cursor: "grab", userSelect: "none", fontFamily: "'JetBrains Mono',monospace" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = item.color + "55"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,255,255,0.06)"; }}>
            <span style={{ fontSize: 15, filter: `drop-shadow(0 0 3px ${item.color}66)` }}>{item.icon}</span>
            <span style={{ fontSize: 11, color: "#D1D5DB", fontWeight: 500 }}>{item.label}</span>
          </div>
        ))}
        <div style={{ marginTop: 16, padding: "8px 10px", borderRadius: 6, border: "1px dashed rgba(255,255,255,0.07)", fontSize: 10, color: "#374151", fontFamily: "'JetBrains Mono',monospace", lineHeight: 1.6 }}>
          Drag onto canvas or describe in chat ↗
        </div>
      </div>
      {/* Canvas */}
      <div ref={wrapperRef} style={{ flex: 1, height: "100%" }}>
        <ReactFlow nodes={nodes} edges={edges}
          onNodesChange={changes => { onNodesChange(changes); emit(nodes, edges); }}
          onEdgesChange={changes => { onEdgesChange(changes); emit(nodes, edges); }}
          onConnect={onConnect} onDrop={onDrop} onDragOver={e => { e.preventDefault(); e.dataTransfer.dropEffect = "move"; }}
          onInit={setRfInstance} nodeTypes={nodeTypes} fitView proOptions={{ hideAttribution: true }}
          style={{ background: "#0D1117" }}
          defaultEdgeOptions={{ animated: true, style: { stroke: "#374151", strokeWidth: 2 } }}>
          <Background variant={BackgroundVariant.Dots} gap={24} size={1} color="#1F2937" />
          <Controls style={{ background: "#161B22", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 8 }} />
          <MiniMap style={{ background: "#161B22", border: "1px solid rgba(255,255,255,0.08)" }}
            nodeColor={n => ({ gke_cluster:"#4285F4",vpc_network:"#34A853",cloud_run_service:"#FBBC04",cloud_sql_instance:"#EA4335",gcs_bucket:"#9C27B0" } as any)[(n.data as NodeConfig)?.resource_type] ?? "#374151"} />
        </ReactFlow>
      </div>
    </div>
  );
}
