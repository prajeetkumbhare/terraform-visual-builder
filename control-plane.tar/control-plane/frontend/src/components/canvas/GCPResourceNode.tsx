import React, { memo } from "react";
import { Handle, Position, type NodeProps } from "reactflow";
import type { NodeConfig, ResourceType } from "../../types";

const META: Record<ResourceType, { icon: string; color: string; label: string }> = {
  gke_cluster:         { icon: "⎈",  color: "#4285F4", label: "GKE Cluster" },
  vpc_network:         { icon: "⬡",  color: "#34A853", label: "VPC Network" },
  cloud_run_service:   { icon: "▶",  color: "#FBBC04", label: "Cloud Run" },
  cloud_sql_instance:  { icon: "⛃",  color: "#EA4335", label: "Cloud SQL" },
  gcs_bucket:          { icon: "◈",  color: "#9C27B0", label: "GCS Bucket" },
  pubsub_topic:        { icon: "⇆",  color: "#00BCD4", label: "Pub/Sub" },
  firestore:           { icon: "🔥", color: "#FF6D00", label: "Firestore" },
  load_balancer:       { icon: "⚖",  color: "#607D8B", label: "Load Balancer" },
  artifact_registry:   { icon: "📦", color: "#795548", label: "Artifact Registry" },
  custom:              { icon: "✦",  color: "#78909C", label: "Custom" },
};

export const GCPResourceNode = memo(({ data, selected }: NodeProps<NodeConfig>) => {
  const m = META[data.resource_type] ?? META.custom;
  return (
    <div style={{
      border: `1px solid ${selected ? m.color : "rgba(255,255,255,0.10)"}`,
      borderRadius: 8,
      background: selected ? "#1a1f2e" : "#111827",
      minWidth: 160,
      boxShadow: selected ? `0 0 0 2px ${m.color}33, 0 4px 20px rgba(0,0,0,0.5)` : "0 2px 10px rgba(0,0,0,0.4)",
      transition: "all 0.15s",
      fontFamily: "'JetBrains Mono', monospace",
      cursor: "pointer",
    }}>
      <div style={{ height: 3, borderRadius: "8px 8px 0 0", background: m.color }} />
      <div style={{ padding: "10px 14px 12px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
          <span style={{ fontSize: 16, filter: `drop-shadow(0 0 4px ${m.color}88)` }}>{m.icon}</span>
          <span style={{ fontSize: 9, fontWeight: 700, letterSpacing: "0.12em", color: m.color, textTransform: "uppercase" }}>{m.label}</span>
        </div>
        <div style={{ fontSize: 12, fontWeight: 700, color: "#F9FAFB", lineHeight: 1.3, marginBottom: 4 }}>{data.display_name}</div>
        <div style={{ fontSize: 9, color: "#6B7280", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 140 }}>{data.target_project_id}</div>
        {data.natural_language_description && (
          <div style={{ marginTop: 6, fontSize: 9, color: "#9CA3AF", fontStyle: "italic", lineHeight: 1.4, overflow: "hidden", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical" as const }}>
            {data.natural_language_description}
          </div>
        )}
      </div>
      <Handle type="target" position={Position.Left}  style={{ background: m.color, border: "2px solid #111827", width: 10, height: 10 }} />
      <Handle type="source" position={Position.Right} style={{ background: m.color, border: "2px solid #111827", width: 10, height: 10 }} />
    </div>
  );
});
GCPResourceNode.displayName = "GCPResourceNode";
