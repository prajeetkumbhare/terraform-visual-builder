import React, { useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import { v4 as uuidv4 } from "uuid";
import { sendChat, approvePlan } from "../../lib/api";
import { useStore } from "../../store";
import type { CanvasState, ChatMessage } from "../../types";

export function ChatPanel({ canvasState }: { canvasState: CanvasState }) {
  const { sessionId, messages, addMessage, isAgentRunning, setAgentRunning, pendingPlan, setPendingPlan, addDeployment, setActiveTab } = useStore();
  const [input, setInput] = useState("");
  const [approving, setApproving] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const history = messages.map(m => ({ role: m.role, content: m.content }));

  async function handleSend() {
    const msg = input.trim();
    if (!msg || isAgentRunning) return;
    addMessage({ id: uuidv4(), role: "user", content: msg, timestamp: new Date().toISOString(), metadata: {} });
    setInput(""); setAgentRunning(true);
    try {
      const r = await sendChat({ sessionId, message: msg, canvasState, conversationHistory: history });
      addMessage(r.message);
      if (r.terraform_plan) setPendingPlan(r.terraform_plan);
    } catch (err: any) {
      addMessage({ id: uuidv4(), role: "assistant", content: `⚠️ **Error**: ${err.message ?? "Something went wrong"}`, timestamp: new Date().toISOString(), metadata: { error: true } });
    } finally { setAgentRunning(false); }
  }

  async function handleApprove() {
    if (!pendingPlan || approving) return;
    setApproving(true);
    try {
      const result = await approvePlan(pendingPlan.plan_id, sessionId);
      addDeployment(result); setPendingPlan(null); setActiveTab("deployments");
      addMessage({ id: uuidv4(), role: "assistant", content: `✅ **Deployment triggered**\n\nBuild \`${result.build_id}\` queued.\n\n[View logs ↗](${result.logs_url})`, timestamp: new Date().toISOString(), metadata: { build_id: result.build_id } });
    } catch (err: any) {
      addMessage({ id: uuidv4(), role: "assistant", content: `⚠️ **Approval failed**: ${err.message}`, timestamp: new Date().toISOString(), metadata: { error: true } });
    } finally { setApproving(false); }
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#0D1117", fontFamily: "'JetBrains Mono',monospace" }}>
      <div style={{ padding: "14px 20px", borderBottom: "1px solid rgba(255,255,255,0.07)", display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{ width: 8, height: 8, borderRadius: "50%", background: isAgentRunning ? "#FBBC04" : "#34A853", boxShadow: `0 0 8px ${isAgentRunning ? "#FBBC04" : "#34A853"}` }} />
        <span style={{ fontSize: 11, color: "#6B7280", letterSpacing: "0.1em" }}>{isAgentRunning ? "AGENT RUNNING" : "CONTROL PLANE AGENT"}</span>
      </div>

      <div style={{ flex: 1, overflowY: "auto", padding: "16px 20px", display: "flex", flexDirection: "column", gap: 16 }}>
        {messages.length === 0 && (
          <div style={{ margin: "auto", textAlign: "center", color: "#374151", fontSize: 12, lineHeight: 1.8 }}>
            <div style={{ fontSize: 32, marginBottom: 12 }}>⎈</div>
            <div>Describe your infrastructure in natural language.</div>
            <div style={{ marginTop: 4, fontSize: 11 }}>Or drag resources onto the canvas first.</div>
          </div>
        )}
        {messages.map(m => <MsgBubble key={m.id} msg={m} />)}
        {isAgentRunning && <Typing />}
        {pendingPlan && !isAgentRunning && <ApproveBanner plan={pendingPlan} onApprove={handleApprove} onReject={() => setPendingPlan(null)} loading={approving} />}
        <div ref={bottomRef} />
      </div>

      <div style={{ padding: "12px 16px", borderTop: "1px solid rgba(255,255,255,0.07)" }}>
        <div style={{ display: "flex", gap: 8, background: "#161B22", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, padding: "8px 12px" }}>
          <textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key==="Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
            placeholder="Describe infrastructure or ask a question… (Enter to send)"
            disabled={isAgentRunning} rows={2}
            style={{ flex: 1, background: "transparent", border: "none", outline: "none", color: "#F9FAFB", fontSize: 12, fontFamily: "inherit", resize: "none", lineHeight: 1.6 }} />
          <button onClick={handleSend} disabled={isAgentRunning || !input.trim()}
            style={{ alignSelf: "flex-end", background: isAgentRunning || !input.trim() ? "#1F2937" : "#4285F4", border: "none", borderRadius: 6, color: isAgentRunning || !input.trim() ? "#4B5563" : "#fff", cursor: isAgentRunning || !input.trim() ? "not-allowed" : "pointer", fontSize: 16, padding: "6px 12px" }}>
            ↑
          </button>
        </div>
        <div style={{ fontSize: 9, color: "#374151", marginTop: 6, textAlign: "center" }}>Shift+Enter for newline · Enter to send</div>
      </div>
    </div>
  );
}

function MsgBubble({ msg }: { msg: ChatMessage }) {
  const isUser = msg.role === "user";
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: isUser ? "flex-end" : "flex-start", gap: 4 }}>
      <div style={{ fontSize: 9, color: "#4B5563", letterSpacing: "0.08em", textTransform: "uppercase" }}>{isUser ? "You" : "Agent"}</div>
      <div style={{ maxWidth: "88%", padding: "10px 14px", borderRadius: isUser ? "12px 12px 4px 12px" : "4px 12px 12px 12px", background: isUser ? "#1D4ED8" : "#161B22", border: isUser ? "none" : "1px solid rgba(255,255,255,0.07)", fontSize: 12, color: "#F9FAFB", lineHeight: 1.7 }}>
        {isUser ? <span style={{ whiteSpace: "pre-wrap" }}>{msg.content}</span> : (
          <ReactMarkdown components={{
            code: ({ children }) => <code style={{ background: "#0D1117", padding: "1px 5px", borderRadius: 3, fontSize: 11, color: "#FBBC04" }}>{children}</code>,
            pre: ({ children }) => <pre style={{ background: "#0D1117", padding: 12, borderRadius: 6, overflowX: "auto", fontSize: 11, marginTop: 8, border: "1px solid rgba(255,255,255,0.06)" }}>{children}</pre>,
          }}>{msg.content}</ReactMarkdown>
        )}
      </div>
    </div>
  );
}

function Typing() {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <div style={{ display: "flex", gap: 4 }}>
        {[0,1,2].map(i => <div key={i} style={{ width: 6, height: 6, borderRadius: "50%", background: "#4285F4", animation: `pulse 1.2s ease-in-out ${i*0.2}s infinite` }} />)}
      </div>
      <span style={{ fontSize: 10, color: "#4B5563" }}>Agents processing…</span>
      <style>{`@keyframes pulse { 0%,100%{opacity:.3;transform:scale(.8)} 50%{opacity:1;transform:scale(1.1)} }`}</style>
    </div>
  );
}

function ApproveBanner({ plan, onApprove, onReject, loading }: { plan: any; onApprove: ()=>void; onReject: ()=>void; loading: boolean }) {
  return (
    <div style={{ border: "1px solid #34A85344", borderRadius: 10, background: "linear-gradient(135deg,#0a1f11,#0d1117)", padding: "16px 18px", display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <span style={{ fontSize: 16 }}>🚀</span>
        <span style={{ fontSize: 11, fontWeight: 700, color: "#34A853", letterSpacing: "0.08em" }}>READY TO DEPLOY</span>
      </div>
      <div style={{ fontSize: 11, color: "#9CA3AF" }}>Target: <span style={{ color: "#F9FAFB" }}>{plan.target_project_id}</span></div>
      {plan.resource_summary?.length > 0 && <ul style={{ margin: 0, padding: "0 0 0 14px", fontSize: 11, color: "#D1D5DB", lineHeight: 1.8 }}>{plan.resource_summary.map((r: string, i: number) => <li key={i}>{r}</li>)}</ul>}
      {!plan.is_valid && <div style={{ fontSize: 11, color: "#EA4335" }}>⚠ Validation issues: {plan.validation_errors?.join(", ")}</div>}
      <div style={{ display: "flex", gap: 8 }}>
        <button onClick={onApprove} disabled={loading || !plan.is_valid}
          style={{ flex: 1, padding: "10px 0", background: plan.is_valid ? "#34A853" : "#1F2937", border: "none", borderRadius: 7, color: plan.is_valid ? "#fff" : "#4B5563", fontSize: 12, fontWeight: 700, cursor: plan.is_valid && !loading ? "pointer" : "not-allowed", fontFamily: "'JetBrains Mono',monospace", letterSpacing: "0.06em" }}>
          {loading ? "Triggering…" : "✓ Approve & Deploy"}
        </button>
        <button onClick={onReject} disabled={loading}
          style={{ padding: "10px 16px", background: "transparent", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 7, color: "#6B7280", fontSize: 12, cursor: "pointer", fontFamily: "'JetBrains Mono',monospace" }}>
          Dismiss
        </button>
      </div>
    </div>
  );
}
