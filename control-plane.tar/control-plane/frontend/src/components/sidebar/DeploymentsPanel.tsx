import React, { useEffect } from "react";
import { getBuildStatus } from "../../lib/api";
import { useStore } from "../../store";
import type { BuildStatus, DeploymentResult } from "../../types";

const META: Record<BuildStatus, { color: string; icon: string; label: string }> = {
  queued:    { color:"#6B7280", icon:"○", label:"Queued" },
  working:   { color:"#FBBC04", icon:"◉", label:"Working" },
  success:   { color:"#34A853", icon:"●", label:"Success" },
  failure:   { color:"#EA4335", icon:"✕", label:"Failed" },
  cancelled: { color:"#9CA3AF", icon:"⊘", label:"Cancelled" },
};
const TERMINAL: BuildStatus[] = ["success","failure","cancelled"];

export function DeploymentsPanel() {
  const { deployments, updateDeployment } = useStore();

  useEffect(() => {
    const active = deployments.filter(d => !TERMINAL.includes(d.status));
    if (!active.length) return;
    const iv = setInterval(async () => {
      for (const d of active) { try { updateDeployment(await getBuildStatus(d.build_id)); } catch {} }
    }, 5000);
    return () => clearInterval(iv);
  }, [deployments, updateDeployment]);

  if (!deployments.length) return (
    <div style={{ display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",color:"#374151",fontFamily:"'JetBrains Mono',monospace",gap:12 }}>
      <div style={{ fontSize:36 }}>▶</div>
      <div style={{ fontSize:12 }}>No deployments yet.</div>
      <div style={{ fontSize:11,color:"#1F2937" }}>Approve a Terraform plan to trigger a build.</div>
    </div>
  );

  return (
    <div style={{ display:"flex",flexDirection:"column",height:"100%",background:"#0D1117",fontFamily:"'JetBrains Mono',monospace" }}>
      <div style={{ padding:"12px 20px",borderBottom:"1px solid rgba(255,255,255,0.07)",display:"flex",alignItems:"center",gap:8 }}>
        <span style={{ fontSize:11,color:"#F9FAFB",fontWeight:700 }}>Deployments</span>
        <span style={{ fontSize:9,color:"#4B5563",background:"#161B22",border:"1px solid rgba(255,255,255,0.08)",borderRadius:10,padding:"2px 8px" }}>{deployments.length}</span>
      </div>
      <div style={{ flex:1,overflowY:"auto",padding:"12px 16px",display:"flex",flexDirection:"column",gap:10 }}>
        {deployments.map(d => <Card key={d.build_id} d={d} />)}
      </div>
    </div>
  );
}

function Card({ d }: { d: DeploymentResult }) {
  const m = META[d.status];
  const active = !TERMINAL.includes(d.status);
  const duration = d.started_at && d.finished_at ? Math.round((new Date(d.finished_at).getTime() - new Date(d.started_at).getTime()) / 1000) : null;

  return (
    <div style={{ background:"#161B22",border:`1px solid ${m.color}33`,borderRadius:8,padding:"14px 16px",display:"flex",flexDirection:"column",gap:10 }}>
      <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between" }}>
        <div style={{ display:"flex",alignItems:"center",gap:8 }}>
          <span style={{ color:m.color,fontSize:14 }}>{m.icon}</span>
          <span style={{ fontSize:10,fontWeight:700,color:m.color,letterSpacing:"0.1em" }}>{m.label.toUpperCase()}</span>
        </div>
        <span style={{ fontSize:9,color:"#4B5563" }}>{d.build_id.slice(0,12)}…</span>
      </div>
      <div style={{ fontSize:10,color:"#9CA3AF" }}>Plan: <span style={{ color:"#D1D5DB" }}>{d.plan_id.slice(0,8)}…</span></div>
      {d.started_at && <div style={{ fontSize:9,color:"#4B5563" }}>Started: {new Date(d.started_at).toLocaleTimeString()}{duration !== null ? ` · ${duration}s` : ""}</div>}
      {d.error_message && <div style={{ fontSize:10,color:"#F87171",background:"#1a0a0a",border:"1px solid #EA433522",borderRadius:5,padding:"6px 10px" }}>{d.error_message}</div>}
      {d.logs_url && <a href={d.logs_url} target="_blank" rel="noopener noreferrer" style={{ fontSize:10,color:"#4285F4",textDecoration:"none" }}>View Cloud Build logs ↗</a>}
      {active && (
        <div style={{ height:2,background:"#1F2937",borderRadius:1,overflow:"hidden" }}>
          <div style={{ height:"100%",background:m.color,width:"40%",animation:"progress 1.5s ease-in-out infinite" }} />
          <style>{`@keyframes progress{0%{transform:translateX(-100%)}100%{transform:translateX(350%)}}`}</style>
        </div>
      )}
    </div>
  );
}
