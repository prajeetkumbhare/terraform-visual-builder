import React, { useState } from "react";
import { useStore } from "../../store";

export function TerraformPanel() {
  const { pendingPlan } = useStore();
  const [copied, setCopied] = useState(false);

  if (!pendingPlan) return (
    <div style={{ display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",color:"#374151",fontFamily:"'JetBrains Mono',monospace",gap:12 }}>
      <div style={{ fontSize:36 }}>⬡</div>
      <div style={{ fontSize:12 }}>No plan generated yet.</div>
      <div style={{ fontSize:11,color:"#1F2937" }}>Describe infrastructure in the chat panel.</div>
    </div>
  );

  return (
    <div style={{ display:"flex",flexDirection:"column",height:"100%",background:"#0D1117",fontFamily:"'JetBrains Mono',monospace" }}>
      <div style={{ padding:"12px 20px",borderBottom:"1px solid rgba(255,255,255,0.07)",display:"flex",alignItems:"center",justifyContent:"space-between" }}>
        <div style={{ display:"flex",flexDirection:"column",gap:2 }}>
          <span style={{ fontSize:11,color:"#F9FAFB",fontWeight:700 }}>Terraform Plan</span>
          <span style={{ fontSize:9,color:"#4B5563" }}>{pendingPlan.plan_id.slice(0,8)} · {pendingPlan.target_project_id}</span>
        </div>
        <div style={{ display:"flex",gap:8,alignItems:"center" }}>
          <span style={{ fontSize:9,fontWeight:700,letterSpacing:"0.1em",color:pendingPlan.is_valid?"#34A853":"#EA4335",background:pendingPlan.is_valid?"#0a1f11":"#1a0a0a",border:`1px solid ${pendingPlan.is_valid?"#34A85344":"#EA433544"}`,borderRadius:4,padding:"3px 8px" }}>{pendingPlan.is_valid?"✓ VALID":"✗ INVALID"}</span>
          <button onClick={() => { navigator.clipboard.writeText(pendingPlan.terraform_hcl); setCopied(true); setTimeout(()=>setCopied(false),2000); }}
            style={{ background:"#161B22",border:"1px solid rgba(255,255,255,0.08)",borderRadius:6,color:"#9CA3AF",cursor:"pointer",fontSize:10,padding:"4px 10px",fontFamily:"inherit" }}>
            {copied ? "✓ Copied" : "Copy HCL"}
          </button>
        </div>
      </div>

      {pendingPlan.validation_errors.length > 0 && (
        <div style={{ padding:"10px 20px",background:"#1a0a0a",borderBottom:"1px solid #EA433533" }}>
          <div style={{ fontSize:10,color:"#EA4335",fontWeight:700,marginBottom:6 }}>VALIDATION ERRORS</div>
          {pendingPlan.validation_errors.map((e,i) => <div key={i} style={{ fontSize:11,color:"#F87171",marginBottom:3 }}>› {e}</div>)}
        </div>
      )}

      {pendingPlan.resource_summary.length > 0 && (
        <div style={{ padding:"10px 20px",background:"#0a1117",borderBottom:"1px solid rgba(255,255,255,0.05)",display:"flex",flexWrap:"wrap",gap:6 }}>
          {pendingPlan.resource_summary.map((r,i) => <span key={i} style={{ fontSize:9,color:"#34A853",background:"#0a1f11",border:"1px solid #34A85333",borderRadius:4,padding:"2px 8px" }}>{r}</span>)}
        </div>
      )}

      <div style={{ flex:1,overflowY:"auto",padding:"16px 20px" }}>
        <pre style={{ margin:0,fontSize:11,lineHeight:1.8,color:"#D1D5DB",background:"transparent",whiteSpace:"pre-wrap",wordBreak:"break-word" }}>
          {pendingPlan.terraform_hcl}
        </pre>
      </div>

      <div style={{ padding:"8px 20px",borderTop:"1px solid rgba(255,255,255,0.05)",fontSize:9,color:"#374151",display:"flex",justifyContent:"space-between" }}>
        <span>Generated {new Date(pendingPlan.generated_at).toLocaleTimeString()}</span>
        <span>{pendingPlan.terraform_hcl.split("\n").length} lines</span>
      </div>
    </div>
  );
}
