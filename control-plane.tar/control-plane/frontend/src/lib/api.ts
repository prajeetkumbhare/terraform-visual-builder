import type { CanvasState, ChatResponse, DeploymentResult, TargetProject, TerraformPlan } from "../types";

const BASE = import.meta.env.VITE_API_URL ?? "http://localhost:8080";
const KEY  = import.meta.env.VITE_API_KEY  ?? "";

export class ApiError extends Error {
  constructor(message: string, public status: number, public detail?: unknown) {
    super(message);
    this.name = "ApiError";
  }
}

async function req<T>(path: string, opts: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(KEY ? { "X-API-Key": KEY } : {}),
    ...(opts.headers as Record<string, string>),
  };
  const res = await fetch(`${BASE}${path}`, { ...opts, headers });
  if (!res.ok) {
    let body: { message?: string } = {};
    try { body = await res.json(); } catch {}
    throw new ApiError(body.message ?? `HTTP ${res.status}`, res.status);
  }
  if (res.status === 204) return undefined as T;
  return res.json();
}

export const sendChat = (p: {
  sessionId: string; message: string;
  canvasState: CanvasState; conversationHistory: { role: string; content: string }[];
}) => req<ChatResponse>("/api/v1/chat", {
  method: "POST",
  body: JSON.stringify({
    session_id: p.sessionId, message: p.message,
    canvas_state: p.canvasState, conversation_history: p.conversationHistory,
  }),
});

export const loadCanvas = async (sessionId: string): Promise<CanvasState | null> => {
  try { return await req<CanvasState>(`/api/v1/sessions/${sessionId}/canvas`); }
  catch (e) { if (e instanceof ApiError && e.status === 404) return null; throw e; }
};

export const saveCanvas = (sessionId: string, canvas: CanvasState) =>
  req(`/api/v1/sessions/${sessionId}/canvas`, { method: "PUT", body: JSON.stringify(canvas) });

export const getPlan = (sessionId: string, planId: string) =>
  req<TerraformPlan>(`/api/v1/plans/${sessionId}/${planId}`);

export const approvePlan = (planId: string, sessionId: string) =>
  req<DeploymentResult>(`/api/v1/plans/${planId}/approve`, {
    method: "POST",
    body: JSON.stringify({ session_id: sessionId, approved_by: "user" }),
  });

export const getBuildStatus = (buildId: string) =>
  req<DeploymentResult>(`/api/v1/builds/${buildId}`);

export const listProjects = () => req<TargetProject[]>("/api/v1/projects");
