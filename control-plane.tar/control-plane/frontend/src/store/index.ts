import { create } from "zustand";
import { v4 as uuidv4 } from "uuid";
import type { ChatMessage, DeploymentResult, PanelTab, TerraformPlan, TargetProject } from "../types";

interface Store {
  sessionId: string;
  activeTab: PanelTab;
  messages: ChatMessage[];
  pendingPlan: TerraformPlan | null;
  deployments: DeploymentResult[];
  projects: TargetProject[];
  isAgentRunning: boolean;

  addMessage: (m: ChatMessage) => void;
  setPendingPlan: (p: TerraformPlan | null) => void;
  addDeployment: (r: DeploymentResult) => void;
  updateDeployment: (r: DeploymentResult) => void;
  setProjects: (ps: TargetProject[]) => void;
  setActiveTab: (t: PanelTab) => void;
  setAgentRunning: (v: boolean) => void;
  resetSession: () => void;
}

export const useStore = create<Store>((set, get) => ({
  sessionId: uuidv4(),
  activeTab: "chat",
  messages: [],
  pendingPlan: null,
  deployments: [],
  projects: [],
  isAgentRunning: false,

  addMessage: (m) => set((s) => ({ messages: [...s.messages, m] })),
  setPendingPlan: (p) => set({ pendingPlan: p, activeTab: p ? "terraform" : get().activeTab }),
  addDeployment: (r) => set((s) => ({ deployments: [r, ...s.deployments] })),
  updateDeployment: (r) => set((s) => ({ deployments: s.deployments.map((d) => d.build_id === r.build_id ? r : d) })),
  setProjects: (ps) => set({ projects: ps }),
  setActiveTab: (t) => set({ activeTab: t }),
  setAgentRunning: (v) => set({ isAgentRunning: v }),
  resetSession: () => set({ sessionId: uuidv4(), messages: [], pendingPlan: null, deployments: [] }),
}));
