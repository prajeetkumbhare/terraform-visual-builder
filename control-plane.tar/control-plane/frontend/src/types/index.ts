export type ResourceType =
  | "gke_cluster" | "vpc_network" | "cloud_run_service" | "cloud_sql_instance"
  | "gcs_bucket" | "pubsub_topic" | "firestore" | "load_balancer"
  | "artifact_registry" | "custom";

export interface NodeConfig {
  resource_type: ResourceType;
  display_name: string;
  natural_language_description: string;
  properties: Record<string, unknown>;
  target_project_id: string;
}

export interface CanvasNode {
  id: string;
  type: string;
  position: { x: number; y: number };
  data: NodeConfig;
}

export interface CanvasEdge {
  id: string;
  source: string;
  target: string;
  label: string;
  relationship: "depends_on" | "connects_to" | "peered_with" | "routes_to";
}

export interface CanvasState {
  session_id: string;
  nodes: CanvasNode[];
  edges: CanvasEdge[];
  updated_at: string;
  version: number;
}

export type MessageRole = "user" | "assistant" | "system" | "tool";

export interface ChatMessage {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: string;
  metadata: Record<string, unknown>;
}

export interface AgentMetric {
  agent_name: string;
  model: string;
  input_tokens: number;
  output_tokens: number;
  latency_ms: number;
  finish_reason: string;
}

export interface TerraformPlan {
  plan_id: string;
  session_id: string;
  generated_at: string;
  terraform_hcl: string;
  target_project_id: string;
  resource_summary: string[];
  estimated_cost_usd: number | null;
  gcs_path: string;
  validation_errors: string[];
  is_valid: boolean;
}

export interface ChatResponse {
  session_id: string;
  message: ChatMessage;
  terraform_plan: TerraformPlan | null;
  agent_metrics: AgentMetric[];
}

export type BuildStatus = "queued" | "working" | "success" | "failure" | "cancelled";

export interface DeploymentResult {
  build_id: string;
  plan_id: string;
  session_id: string;
  status: BuildStatus;
  logs_url: string;
  started_at: string | null;
  finished_at: string | null;
  error_message: string | null;
}

export interface TargetProject {
  project_id: string;
  display_name: string;
  secret_name: string;
  region: string;
  is_active: boolean;
}

export type PanelTab = "chat" | "terraform" | "deployments";
