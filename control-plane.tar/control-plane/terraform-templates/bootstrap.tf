# Bootstrap Terraform — provisions the control plane infrastructure itself.
# Run once manually: terraform init && terraform apply

terraform {
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
  }
  backend "gcs" {
    bucket = "REPLACE_WITH_YOUR_BOOTSTRAP_BUCKET"
    prefix = "control-plane/bootstrap"
  }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

variable "project_id" {
  description = "Control plane GCP project ID"
  type        = string
}

variable "region" {
  description = "Default region"
  type        = string
  default     = "us-central1"
}

# ── GCS Bucket — canvas state + generated .tf files ───────────────────────────

resource "google_storage_bucket" "control_plane" {
  name                        = "${var.project_id}-control-plane"
  location                    = var.region
  uniform_bucket_level_access = true
  force_destroy               = false

  versioning {
    enabled = true
  }

  lifecycle_rule {
    action { type = "Delete" }
    condition { age = 90 }
  }

  labels = {
    managed-by = "control-plane-bootstrap"
  }
}

# ── Cloud Build trigger ────────────────────────────────────────────────────────

resource "google_cloudbuild_trigger" "terraform_apply" {
  name        = "control-plane-terraform-apply"
  description = "Triggered by control plane backend to apply generated Terraform"
  project     = var.project_id

  webhook_config {
    secret = google_secret_manager_secret_version.webhook_secret_value.id
  }

  build {
    source {
      storage_source {
        bucket = google_storage_bucket.control_plane.name
        object = "cloudbuild/cloudbuild.yaml"
      }
    }

    substitutions = {
      _SESSION_ID    = ""
      _PLAN_ID       = ""
      _TF_GCS_PATH   = ""
      _TARGET_PROJECT = ""
      _SA_SECRET_NAME = ""
      _OPERATION     = "apply"
      _GCS_BUCKET    = google_storage_bucket.control_plane.name
    }

    timeout = "1200s"

    options {
      logging      = "CLOUD_LOGGING_ONLY"
      machine_type = "E2_MEDIUM"
    }
  }
}

# ── Secret Manager — webhook secret ───────────────────────────────────────────

resource "google_secret_manager_secret" "webhook_secret" {
  secret_id = "cloud-build-webhook-secret"
  project   = var.project_id

  replication {
    auto {}
  }
}

resource "google_secret_manager_secret_version" "webhook_secret_value" {
  secret      = google_secret_manager_secret.webhook_secret.id
  secret_data = "REPLACE_WITH_SECURE_RANDOM_VALUE"

  lifecycle {
    ignore_changes = [secret_data]
  }
}

# ── Service Account — Cloud Build runtime SA ───────────────────────────────────

resource "google_service_account" "cloud_build_sa" {
  account_id   = "control-plane-build"
  display_name = "Control Plane Cloud Build SA"
  project      = var.project_id
}

resource "google_project_iam_member" "build_sa_secret_accessor" {
  project = var.project_id
  role    = "roles/secretmanager.secretAccessor"
  member  = "serviceAccount:${google_service_account.cloud_build_sa.email}"
}

resource "google_project_iam_member" "build_sa_storage" {
  project = var.project_id
  role    = "roles/storage.objectAdmin"
  member  = "serviceAccount:${google_service_account.cloud_build_sa.email}"
}

resource "google_project_iam_member" "build_sa_logging" {
  project = var.project_id
  role    = "roles/logging.logWriter"
  member  = "serviceAccount:${google_service_account.cloud_build_sa.email}"
}

# ── Outputs ────────────────────────────────────────────────────────────────────

output "gcs_bucket_name" {
  value = google_storage_bucket.control_plane.name
}

output "cloud_build_trigger_id" {
  value = google_cloudbuild_trigger.terraform_apply.trigger_id
}
